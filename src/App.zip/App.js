import React from 'react';
import Img from './Componentes/Img';
import mergeImages from 'merge-images';


const clientID = 'RjsPMJAfMUwT7iB5GcUaqzG8gTmq1ogfXYpaKZYkQmU';
const endpoint = 'https://api.unsplash.com/search/photos';


export default class App extends React.Component {
 
  constructor(){
    super();
    this.query='';
    this.trackQueryValue = this.trackQueryValue.bind(this);
    this.search = this.search.bind(this);

    this.state= { 
      images:[],
      imagen: null, 
      listado:[]
    }
  } 

  search(){
      fetch(`${endpoint}?query=${this.query}&client_id=${clientID}&per_page=3&orientation=landscape`)
    .then(response=>{
      return response.json()
    }).then(jsonResponse=>{
      console.log(jsonResponse);
      return jsonResponse.results;
    }).then(results => this.marge(results))
  }

  marge(jsonImagenes) {
     
    var arrayImagenes = jsonImagenes.map(images=>{return images.urls.small}) 
    console.log(arrayImagenes);
    var b64 =  mergeImages(arrayImagenes,{crossOrigin : "Anonymous"})
     .then(b64 => {this.setState({imagen:b64})});
 }

  trackQueryValue(ev){
    this.query = ev.target.value;
  }

  images(){
    return this.state.images.map(images=>{ 
      return  images.urls.thumb
      
    }) 
  }
  
 // listado = image.map(nombre => ({ value: person.id, text: person.name }));
 

  render(){
    return(<div>
      <input type="text" onChange={this.trackQueryValue}/>
      <button onClick={this.search}>Buscar</button>
      <div> {this.images()}</div> 
      <img src={this.state.imagen}crossorigin="anonymous" />
    </div>);
  }
  
}