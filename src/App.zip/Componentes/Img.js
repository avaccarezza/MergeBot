import React , {Component} from 'react';
import mergeImages from 'merge-images';


export default class Img extends Component {
  
  constructor(props){
    super(props);   
    this.state= { 
        imagen: null 
      }
}
marge() {
    var b64 =  mergeImages(this.props.listado)
     .then(b64 => {this.setState({imagen:b64}) });
 }


render(){
    return (
         <div>
             <img src={this.state.imagen}/>
         </div>
    );
  }
 
}